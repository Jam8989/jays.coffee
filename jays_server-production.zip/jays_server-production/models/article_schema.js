var mongoose = require("mongoose");

var articleSchema = mongoose.Schema({
  name: String,
  article: String,
});

var Article = mongoose.model("article", articleSchema, "articles");

module.exports = Article;
