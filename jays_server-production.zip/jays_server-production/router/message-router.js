const express = require("express");
const router = express.Router();
const transporter = require("../helpers/mailTransporter");
const { authenticate } = require("../middleware/authenticate");
const { csrfCheck } = require("../middleware/csrfCheck");

const Message = require("../models/message_schema");

router.post("/", async (req, res) => {
  let message = new Message({
    name: req.body.name,
    email: req.body.email,
    theme: req.body.theme,
    message: req.body.message,
  });

  try {
    await message.save();
    await transporter.sendMail({
      from: req.body.email,
      to: process.env.SMTP_USER,
      subject: `Тема: ${req.body.theme} от ${req.body.name} ${req.body.email}`,
      text: req.body.message,
    })
    res.status(200).send("OK"); 
  } catch (e) {
    res.status(500).send(e);
  }
});

// must check cookies and token - HOW TO?

router.get("/", authenticate, csrfCheck, (req, res) => {
  Message.find().exec((err, messages) => {
    if (err) return res.status(500).json(err);
    return res.status(200).json(messages);
  });
});


router.delete("/", authenticate, csrfCheck, (req, res) => {
  Message.findByIdAndDelete(req.body.id, (err, result) => {
    if (err) return res.status(500).json(err);
    return res.status(200).json(result);
  })
})

module.exports = router;