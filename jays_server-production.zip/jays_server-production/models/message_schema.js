var mongoose = require("mongoose");

var messageSchema = mongoose.Schema({
  name: String,
  email: String,
  theme: String,
  message: String,
});

var Message = mongoose.model("message", messageSchema, "messages");

module.exports = Message;
