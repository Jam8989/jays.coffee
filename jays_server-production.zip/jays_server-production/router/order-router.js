const express = require("express");
const router = express.Router();
const { authenticate } = require("../middleware/authenticate");
const { csrfCheck } = require("../middleware/csrfCheck");

const Order = require("../models/order_schema");

router.post("/", (req, res) => {
  let order = new Order({
    name: req.body.name,
    phone: req.body.phone,
    point: req.body.point,
    date: new Date(req.body.date),
    time: req.body.time,
    cartForOrder: req.body.cartForOrder,
    totalOrderPrice: req.body.totalOrderPrice,
  });
  order
    .save()
    .then(item => {
      res.status(200).send("OK");
    })
    .catch(err => {
      res.status(500).send(err);
    });
});

router.get("/", authenticate, csrfCheck, (req, res) => {
  const page = parseInt(req.query.page) || 0;
  const limit = parseInt(req.query.limit) || 0;
  if (page && limit) {
    Order.find().sort({ date: -1 }).skip((page - 1) * limit).limit(limit).exec((err, orders) => {
      if (err) return res.status(500).json(err);
      Order.count().exec((err, count) => {
        if (err) return res.status(500).json(err);
        return res.status(200).json({ orders, count });
      });
    })
  } else {
    res.status(404).json({ message: "URL should have parameters page and limit!" })
  }
})

router.post("/day-filter", authenticate, csrfCheck, (req, res) => {
  const startDate = new Date(req.body.data.date).setHours(0, 0, 0);
  const endDate = new Date(req.body.data.date).setHours(23, 59, 59);
  Order.find({ date: { "$gte": startDate, "$lt": endDate } }).exec((err, orders) => {
    if (err) return res.status(500).json(err);
    return res.status(200).json({ orders });
  })
})

module.exports = router;

/*
    Order.find().sort({ date: -1 }).limit(10).exec((err, orders) => {
      if (err) return res.status(500).json(err);
      Order.count().exec((err, count) => {
        if (err) return res.status(500).json(err);
        res.status(200).json({ orders, count });
      });
    })
*/