var express = require("express");
const router = express.Router();

var Article = require("../models/article_schema");

router.get("/", (req, res) => {
  Article.findOne({ name: "Phylosophy" }, { _id: 0 }).exec((err, article) => {
    if (err) return res.status(500).json(err);
    return res.status(200).json(article);
  });
});

module.exports = router;
