var mongoose = require("mongoose");

const productSchema = mongoose.Schema({
  name: String,
  price: String,
  weight: String,
  mainPhoto: String,
  otherPhotos: [String],
  type: String,
  region: String,
  height: String,
  processing: String,
  assessment: String,
  harvestYear: String,
  article: String,
});

const Product = mongoose.model("product", productSchema, "products");

module.exports = Product;
