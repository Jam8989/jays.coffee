var mongoose = require("mongoose");

const pointSchema = mongoose.Schema({
  name: String,
  imageURL: String,
  lat: Number,
  lng: Number,
  mainImageURL: String,
  pointName: String,
  pointDescription: String,
  neighborhoodPoints: [
    {
      _id: mongoose.Schema.Types.ObjectId,
      name: String,
      imageURL: String,
    },
  ],
  shopData: {
    address: String,
    tel: String,
    workTime: String,
  },
});

const Point = mongoose.model("point", pointSchema, "points");

module.exports = Point;
