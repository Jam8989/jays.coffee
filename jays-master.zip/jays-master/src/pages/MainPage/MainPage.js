import React, { Component } from "react";

class MainPage extends Component {
  render() {
    return (
      <div>
        <p id="abc">HEEY</p>
      </div>
    );
  }
}

export default MainPage;
