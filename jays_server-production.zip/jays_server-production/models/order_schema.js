var mongoose = require("mongoose");

var orderSchema = mongoose.Schema({
  name: String,
  phone: String,
  point: String,
  date: Date,
  time: String,
  cartForOrder: [
    {
      nameProduct: String,
      priceProduct: String,
      quantityProduct: Number,
    },
  ],
  totalOrderPrice: Number,
});

var Order = mongoose.model("order", orderSchema, "orders");

module.exports = Order;
