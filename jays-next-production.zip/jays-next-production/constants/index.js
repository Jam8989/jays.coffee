// locations consts
export const TOGGLE_LOCATIONS_MENU = "TOGGLE_LOCATIONS_MENU";
export const SET_LOCATIONS = "SET_LOCATIONS";
export const SET_MAP = "SET_MAP";
// pointInfo consts
export const SET_POINT_DATA = "SET_POINT_DATA";
export const SET_MINI_MAP = "SET_MINI_MAP";
// message modal consts
export const SHOW_MESSAGE_MODAL = 'SHOW_MESSAGE_MODAL';
export const CLOSE_MESSAGE_MODAL = 'CLOSE_MESSAGE_MODAL';
// app actions consts
export const SET_SHOW_MOBILE_NAV_BAR = 'SET_SHOW_MOBILE_NAV_BAR';
