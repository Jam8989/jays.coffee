const express = require("express");
const router = express.Router();

const Point = require("../models/point_schema");

router.get("/", (req, res) => {
  Point.find({}, { _id: 1, pointName: 1, imageURL: 1, lat: 1, lng: 1, shopData: 1 }).exec((err, locations) => {
    if (err) return res.status(500).json(err);
    return res.status(200).json(locations);
  });
});

router.get("/:pointId", (req, res) => {
  Point.findById(req.params.pointId).exec((err, pointData) => {
    if (err) return res.status(500).json(err);
    return res.status(200).json(pointData);
  });
});

module.exports = router;
