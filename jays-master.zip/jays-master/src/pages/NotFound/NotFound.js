import React from "react";

function NotFound() {
  return <div>Error 404: Page not Found</div>;
}

export default NotFound;
