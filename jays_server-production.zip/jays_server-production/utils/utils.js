const Session = require("../models/session");

const initSession = async userId => {
  const token = await Session.generateToken();
  const csrfToken = await Session.generateToken();
  const session = new Session({ token, csrfToken, userId });
  await session.save();
  return session;
};

const isEmail = email => {
  if (typeof email !== "string") {
    return false;
  }
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  return emailRegex.test(email);
};

module.exports = { initSession, isEmail };
