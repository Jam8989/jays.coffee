var mongoose = require("mongoose");

var newClientSchema = mongoose.Schema({
  email: String,
  surname: String,
  name: String,
  birthday: Date,
  phone: String,
});

var NewClient = mongoose.model("new_client", newClientSchema, "new_clients");

module.exports = NewClient;
