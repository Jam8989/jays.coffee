const express = require("express");
const router = express.Router();
const request = require("request");
const NewClient = require("../models/newClient_schema");
const Client = require("../models/client_schema");
const transporter = require("../helpers/mailTransporter");
const env = process.env;
const { authenticate } = require("../middleware/authenticate");
const { csrfCheck } = require("../middleware/csrfCheck");

router.post("/new", async (req, res) => {
  const { email, surname, name, birthday, phone } = req.body;

  // check by phone number is the user registered
  // in new_clients and clients collection

  // WARNING! phone example - 380967745690

  let findedClient = null;
  await NewClient.findOne({ phone })
    .then(result => {
      findedClient = result;
    })
    .catch(err => {
      return res.status(500).json({ message: "Something went wrong", err });
    });
  if (!findedClient) {
    await Client.findOne({ phone_number: phone })
      .then(result => {
        findedClient = result;
      })
      .catch(err => {
        return res.status(500).json({ message: "Something went wrong", err });
      });
  }

  if (findedClient)
    return res
      .status(409)
      .json({
        message: "A client with this phone number is already registered!"
      });

  const newClient = new NewClient({
    email: email,
    surname: surname,
    name: name,
    birthday: new Date(birthday),
    phone: phone
  });

  newClient
    .save()
    .then(item => {
      return res.status(200).json({
        message:
          "Client was created. Please, wait while the administrator checks your request"
      });
    })
    .catch(err => {
      return res.status(500).json({ message: "Something went wrong", err });
    });
});

router.get("/new", authenticate, csrfCheck, (req, res) => {
  NewClient.find()
    .then(newClients => {
      return res.status(200).json(newClients);
    })
    .catch(err => {
      return res.status(500).json({ message: "Something went wrong", err });
    });
});

router.post("/", authenticate, csrfCheck, (req, res) => {
  const { email, surname, name, birthday, phone } = req.body.client;

  const client_obj = {
    client_name: `${surname} ${name}`,
    client_groups_id_client: env.DEFAULT_CLIENT_GROUP,
    phone: `+${phone}`, // format +380985441233
    email,
    birthday // format "Y-m-d"
  };

  // 1. create request for save client in poster

  const options = {
    url: `${env.POSTER_API}clients.createClient?format=json&token=${env.ACCESS_TOKEN}`,
    body: JSON.stringify(client_obj)
  };

  request.post(options, (err, response, body) => {
    if (err)
      return res.status(500).json({ message: "Something went wrong", err });
    const data = JSON.parse(body);
    if (data.error)
      return res.status(500).json({ message: data.message, error: data.error });
    const clientId = data.response;
    // 2. get Client info from poster
    request.get(
      `${env.POSTER_API}clients.getClient?token=${env.ACCESS_TOKEN}&client_id=${clientId}`,
      (err, response, body) => {
        if (err)
          return res.status(500).json({ message: "Something went wrong", err });
        const data = JSON.parse(body);
        if (data.error)
          return res
            .status(500)
            .json({ message: data.message, error: data.error });
        const newPosterClient = data.response[0]; // because array
        const {
          client_id,
          firstname,
          lastname,
          bonus,
          phone,
          phone_number,
          email,
          birthday,
          client_groups_id,
          client_groups_discount,
          birthday_bonus
        } = newPosterClient;
        const posterClient = new Client({
          client_id,
          firstname,
          lastname,
          bonus,
          phone,
          phone_number,
          email,
          birthday,
          client_groups_id,
          client_groups_discount,
          birthday_bonus
        });
        // 3. save client to mongoDB in clients collection
        posterClient
          .save()
          .then(result => {
            // 4. remove client info from new_clients collection
            NewClient.deleteOne({ phone: phone_number }, err => {
              if (err)
                res.status(500).json({ message: "Something went wrong", err });
              transporter.sendMail({
                from: process.env.SMTP_USER,
                to: email,
                subject: "JAYS COFFEE", 
                text: 
                  `Ви були успішно зареєстровані в бонусній системі JAYS COFFEE. Тут ${process.env.FRONT_URL}/rewards ви можете перевіряти баланс ваших бонусів. Дякуємо за реєстрацію!`
              });
              return res
                .status(200)
                .json({ message: "Client was successfully created!" }); 
            });
          })
          .catch(err => {
            return res
              .status(500)
              .json({ message: "Something went wrong", err });
          });
      }
    );
  });
});

// example /clients/bonus?phone=380662304363
router.get("/bonus", async (req, res) => {
  let clientId = null;
  await Client.findOne({ phone_number: req.query.phone })
    .then(client => {
      if (client) clientId = client.client_id;
    })
    .catch(err => {
      return res.status(500).json({ message: "Something went wrong", err });
    });
  if (!clientId)
    return res
      .status(404)
      .json({ message: "Client with this phone not found" });
  request.get(
    `${env.POSTER_API}clients.getClient?format=json&token=${env.ACCESS_TOKEN}&client_id=${clientId}`,
    (err, response, body) => {
      if (err)
        return res.status(500).json({ message: "Something went wrong", err });
      const data = JSON.parse(body);
      if (data.error)
        return res
          .status(500)
          .json({ message: data.message, error: data.error });
      const client = data.response[0];
      const {
        client_id,
        firstname,
        lastname,
        bonus,
        phone,
        phone_number,
        email,
        birthday,
        client_groups_id,
        client_groups_discount,
        birthday_bonus
      } = client;
      Client.updateOne(
        { client_id },
        {
          firstname,
          lastname,
          bonus,
          phone,
          phone_number,
          email,
          birthday,
          client_groups_id,
          client_groups_discount,
          birthday_bonus
        }
      )
        .then(result => {
          return res.status(200).json({
            firstname,
            lastname,
            bonus: `${+bonus / 100}`,
            phone
          });
        })
        .catch(err => {
          return res.status(500).json({ message: "Something went wrong", err });
        });
    }
  );
});

// example http://localhost:3001/clients/new?mongo_client_id=5d5c4055f35af50a4c833142
router.delete("/new", authenticate, csrfCheck, async (req, res) => {
  NewClient.findByIdAndDelete(req.query.mongo_client_id)
    .then(result => {
      if (!result)
        res.status(404).json({ message: "New Client with this id not found!" });
      return res
        .status(200)
        .json({ message: "New Client was successfully deleted!" });
    })
    .catch(err => {
      return res.status(500).json({ message: "Something went wrong", err });
    });
});

router.get("/synchronization", authenticate, csrfCheck, async (req, res) => {
  // synchronization clients from poster
  request.get(
    `${env.POSTER_API}clients.getClients?format=json&token=${env.ACCESS_TOKEN}`,
    (err, response, body) => {
      if (err)
        return res.status(500).json({ message: "Something went wrong", err });
      const data = JSON.parse(body);
      if (data.error)
        return res
          .status(500)
          .json({ message: data.message, error: data.error });
      const clients = data.response;

      clients.forEach(async client => {
        const {
          client_id,
          firstname,
          lastname,
          bonus,
          phone,
          phone_number,
          email,
          birthday,
          client_groups_id,
          client_groups_discount,
          birthday_bonus
        } = client;
        const posterClient = new Client({
          client_id,
          firstname,
          lastname,
          bonus,
          phone,
          phone_number,
          email,
          birthday,
          client_groups_id,
          client_groups_discount,
          birthday_bonus
        });

        let findedClient = null;
        await Client.findOne({ client_id })
          .then(result => {
            findedClient = result;
          })
          .catch(err => {
            return res
              .status(500)
              .json({ message: "Something went wrong", err });
          });

        if (!findedClient) {
          await posterClient.save().catch(err => {
            return res
              .status(500)
              .json({ message: "Something went wrong", err });
          });
        } else {
          await Client.updateOne(
            { client_id },
            {
              firstname,
              lastname,
              bonus,
              phone,
              phone_number,
              email,
              birthday,
              client_groups_id,
              client_groups_discount,
              birthday_bonus
            }
          ).catch(err => {
            return res
              .status(500)
              .json({ message: "Something went wrong", err });
          });
        }
      });

      return res.status(200).json({ message: "Sync was successful" });
    }
  );
});

module.exports = router;
