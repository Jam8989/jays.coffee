var mongoose = require("mongoose");

var clientSchema = mongoose.Schema({
  client_id: String,
  firstname: String,
  lastname: String,
  bonus: String,
  phone: String,
  phone_number: String,
  email: String,
  birthday: String,
  client_groups_id: String,
  client_groups_discount: String,
  birthday_bonus: String,
});

var Client = mongoose.model("client", clientSchema, "clients");

module.exports = Client;
