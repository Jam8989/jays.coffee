var express = require("express");
var cors = require("cors");
var app = express();
var bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
var mongoose = require("mongoose");

mongoose.Promise = global.Promise;

// clear warnings - https://mongoosejs.com/docs/deprecations.html :)
mongoose.set('useCreateIndex', true);
mongoose.set('useNewUrlParser', true);
mongoose.set('useFindAndModify', false);

require("dotenv").config();

var env = process.env;

const URL_DB = `mongodb://${env.MONGO_DB_USERNAME}:${env.MONGO_DB_PASSWORD}@${env.MONGO_DB_HOST}:${env.MONGO_DB_PORT}/${env.MONGO_DB_DATABASE}`;

var philosophyRouter = require("./router/philosophy-router.js");
var locationsRouter = require("./router/locations-router.js");
var shopRouter = require("./router/shop-router.js");
var messageRouter = require("./router/message-router.js");
var orderRouter = require("./router/order-router.js");
var clientsRouter = require("./router/clients-router");
const path = require("path");
const userRoute = require("./router/user-router");

/* 
   Возвращает промежуточное программное обеспечение, 
   которое анализирует только тела с урлен-кодом и просматривает только те запросы, 
   в которых заголовок Content-Type соответствует параметру type. 
   Новый req.body(), содержащий проанализированные данные, 
   заполняется в объекте запроса после промежуточного программного обеспечения (т.е. req.body). 
   Этот объект будет содержать пары ключ-значение.
*/

var corsOptions = {
  origin: ["http://165.22.71.123:3002", "http://165.22.71.123:3000", "http://jays.coffee", "http://jays.coffee:3002", "http://localhost:3000", "http://localhost:3002", "https://bs-local.com:3000", "*"],  //white list
  methods: "GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS",
  credentials: true,
};

app.use(cors(corsOptions));
app.use(bodyParser.json({ limit: "50mb" })); // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true, limit: "50mb" })); // for parsing application/x-www-form-urlencoded
app.use(cookieParser());

mongoose.connect(URL_DB, { useNewUrlParser: true });

var db = mongoose.connection;

db.on("error", console.error.bind(console, "connection error:"));

db.once("open", () => {
  console.log("Successfully connected to database.");
});

var serverImgPath = path.basename("./server-img");
app.use(express.static(serverImgPath));

app.use("/philosophy", philosophyRouter);
app.use("/locations", locationsRouter);
app.use("/shop", shopRouter);
app.use("/message", messageRouter);
app.use("/order", orderRouter);
app.use("/user", userRoute);
app.use("/clients", clientsRouter);

app.use("/*", function (req, res) {
  res.status(404).send({ error: true, message: "Not found such route. please read API documentation" });
});

app.listen(env.APP_PORT, () => {
  console.log(`Server running on port ${env.APP_PORT}.`);
});
