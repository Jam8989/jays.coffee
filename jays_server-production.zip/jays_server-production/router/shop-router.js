const env = process.env;
const express = require("express");
const router = express.Router();
const random = require("../helpers/random");
const multer = require("multer");
const fs = require('fs') // for remove file from disk - native node js
const { authenticate } = require("../middleware/authenticate");
const { csrfCheck } = require("../middleware/csrfCheck");


const storage = multer.diskStorage({
  destination: (req, file, callback) => {
    callback(null, "./server-img/products/"); //куда сохранять null - м.б. ошибка
  },
  filename: (req, file, callback) => {
    callback(null, random() + "_" + file.originalname); //под каким имененем null - м.б. ошибка
  },
});

const Product = require("../models/product_schema");

router.get("/", (req, res) => {
  Product.find({}, { _id: 1, name: 1, mainPhoto: 1, price: 1 }).exec((err, products) => {
    if (err) return res.status(500).json(err);
    return res.status(200).json(products);
  });
});

router.get("/all", (req, res) => {
  Product.find().exec((err, products) => {
    if (err) return res.status(500).json(err);
    return res.status(200).json({ products });
  })
})

router.get("/:productId", (req, res) => {
  Product.findOne({ _id: req.params.productId }).exec((err, productData) => {
    if (err) return res.status(500).json(err);
    return res.status(200).json(productData);
  });
});

const fileFilter = (req, file, callback) => {
  // приниммаем только файлы png, jpg
  if (file.mimetype === "image/png" || file.mimetype === "image/jpeg" || file.mimetype === "image/jpg") {
    callback(null, true);
  } else {
    callback(new Error("File is not .png, .jpeg or .jpg"), false);
  }
};

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 1024 * 1024 * 5, // файлы до 5MB
  },
  fileFilter: fileFilter,
}).fields([{ name: 'mainPhoto', maxCount: 1 }, { name: 'otherPhotos[]', maxCount: 5 }]);


router.post("/", authenticate, csrfCheck, upload, (req, res) => {
  const { name, price, weight, type, region, height, processing, assassment, harvestYear, article } = req.body;
  const mainPhoto = env.APP_URL + req.files.mainPhoto[0].path.replace("server-img", "").replace(/\\/g, "/");
  const otherPhotos = req.files["otherPhotos[]"].map(item => {
    return env.APP_URL + item.path.replace("server-img", "").replace(/\\/g, "/");
  })
  const product = new Product({
    name,
    price,
    weight,
    mainPhoto,
    otherPhotos,
    type,
    region,
    height,
    processing,
    assassment,
    harvestYear,
    article,
  })
  product
    .save()
    .then(result => {
      res.status(200).send(result);
    })
    .catch(err => {
      console.log(err)
      res.status(500).send(err);
    });
})

router.delete("/delete", authenticate, csrfCheck, (req, res) => {
  Product.findByIdAndDelete(req.body.idProduct, (err, result) => {
    if (err) return res.status(500).json(err);
    const pathFiles = [];
    pathFiles.push("./server-img" + result.mainPhoto.replace(env.APP_URL, ""));
    result.otherPhotos.forEach(elem => {
      pathFiles.push("./server-img" + elem.replace(env.APP_URL, ""));
    })
    try {
      pathFiles.forEach(path => {
        fs.unlinkSync(path)
      });
    } catch (err) {
      return res.status(500).json(err);
    }
    Product.find().exec((err, products) => {
      if (err) return res.status(500).json(err);
      return res.status(200).json({ products });
    })
  })
})

router.put("/:productId", authenticate, csrfCheck, (req, res) => {
  const { name, price, weight, type, region, height, processing, assessment, harvestYear, article } = req.body;
  Product.findOneAndUpdate(
    { _id: req.params.productId },
    { $set: { name, price, weight, type, region, processing, height, assessment, harvestYear, article } }
  ).exec((err, result) => {
    if (err) return res.status(500).json(err);
    return res.status(200).json(result);
  })
})

module.exports = router;
